import requests
import time
import tkinter as tk
from threading import Thread
from tkinter import messagebox
from bs4 import BeautifulSoup

# Headers ตาม request ล่าสุด
headers = {
    "Host": "smoner.com",
    "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
    "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7",
    "Accept-Language": "en-US,en;q=0.9",
    "Accept-Encoding": "gzip, deflate, br",
    "Origin": "https://smoner.com",
    "Referer": "https://smoner.com/auth/signin",
    "Sec-Fetch-Site": "same-origin",
    "Sec-Fetch-Mode": "navigate",
    "Sec-Fetch-User": "?1",
    "Sec-Fetch-Dest": "document",
    "Priority": "u=0, i",
    "Sec-Ch-Ua": '"Not)A;Brand";v="8", "Chromium";v="138"',
    "Sec-Ch-Ua-Mobile": "?0",
    # ต้องอัพเดท cookies ใหม่จาก Burp Suite หลัง login
    "Cookie": "csrfToken=bbb922603e6ab4565aba9544fc4e1378c3e988dd223993116ab98ae90957ee3410462f8923b3cf1ce6655161f6e49dc1d8180c3fa0474657b9e0ba9d44c559f0; ab=2; cf_clearance=1M44C7tHMPEZxzBiWh9kAd5..cV_DrIcI3qVE8kTKZQ-1753842578-1.2.1.1-Pm48UFC_Py6GFxQQH6qnQPJuIofxn8Kj9PEl0S6gYjCNWQHbXlLGNvYH7ti7DQyQaKgiuagPWEVRGVqVnuQesSVQljLE6XT9qgRSlF_44JBiTsTeyM7VhKFbbrplLwU5jCQyvGtnd0AXVRfZzZdTVs4nrBAAAkHo.PP.JxUDrUkD1dbwb8kPLj_sn0pMjGdHGxgkrZPbrlUy2EqAVFIWv4Ge9ekpSRg6fRDQpV3nG2QcjwlPO.vjzzcDAVcW1bWD; AppSession=22telgl41ld122i4rs6autegek; RememberMe=H6jCQhmO2QLA%3AfKmNG85qtJnKGc%2B1DinuGltZ9X0AygUTosrSZBLuacZl"
}

# ฟังก์ชันดึง balance
def fetch_balance():
    try:
        response = requests.get("https://smoner.com/member/dashboard", headers=headers, timeout=10)
        response.raise_for_status()
        soup = BeautifulSoup(response.text, 'html.parser')
        balance_elem = soup.select_one("li.dropdown.messages-menu a span.hidden-xs + span")
        if balance_elem:
            return balance_elem.text.strip().replace("$", "")
        return "N/A"
    except requests.RequestException as e:
        print(f"Error fetching balance: {e}")
        return None

# UI ด้วย Tkinter
class BalanceApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Real-time Balance - Smoner")
        self.root.geometry("300x100")
        
        self.label = tk.Label(root, text="Balance: $N/A", font=("Arial", 16))
        self.label.pack(pady=20)
        
        self.running = True
        self.thread = Thread(target=self.update_balance)
        self.thread.daemon = True
        self.thread.start()
        
    def update_balance(self):
        while self.running:
            balance = fetch_balance()
            if balance is not None and balance != "N/A":
                self.label.config(text=f"Balance: ${balance}")
            else:
                self.label.config(text="Balance: Error")
                messagebox.showerror("Error", "Failed to fetch balance. Check your connection or cookies.")
            time.sleep(5)  # อัพเดททุก 5 วินาที
    
    def on_closing(self):
        self.running = False
        self.root.destroy()

def main():
    root = tk.Tk()
    app = BalanceApp(root)
    root.protocol("WM_DELETE_WINDOW", app.on_closing)
    root.mainloop()

if __name__ == "__main__":
    main()